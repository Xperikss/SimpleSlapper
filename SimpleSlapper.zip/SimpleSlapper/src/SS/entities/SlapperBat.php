<?php

declare(strict_types=1);

namespace SS\entities;

class SlapperBat extends SlapperEntity {

    const TYPE_ID = 19;
    const HEIGHT = 0.9;

}
