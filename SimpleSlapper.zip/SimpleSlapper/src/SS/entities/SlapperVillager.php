<?php

declare(strict_types=1);

namespace SS\entities;

class SlapperVillager extends SlapperEntity {

    const TYPE_ID = 15;
    const HEIGHT = 1.95;

}
