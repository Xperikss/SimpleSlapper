<?php

declare(strict_types=1);

namespace SS\entities;

class SlapperStray extends SlapperEntity {

    const TYPE_ID = 46;
    const HEIGHT = 1.99;

}
