<?php

declare(strict_types=1);

namespace SS\entities\other;

use SS\entities\SlapperEntity;

class SlapperMinecart extends SlapperEntity {

    const TYPE_ID = 84;
    const HEIGHT = 0.7;

}
