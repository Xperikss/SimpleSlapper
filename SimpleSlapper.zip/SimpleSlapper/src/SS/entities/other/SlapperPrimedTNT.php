<?php

declare(strict_types=1);

namespace SS\entities\other;

use SS\entities\SlapperEntity;

class SlapperPrimedTNT extends SlapperEntity {

    const TYPE_ID = 65;
    const HEIGHT = 0.98;

}