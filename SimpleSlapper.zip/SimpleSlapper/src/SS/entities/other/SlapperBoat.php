<?php

declare(strict_types=1);

namespace SS\entities\other;

use SS\entities\SlapperEntity;

class SlapperBoat extends SlapperEntity {

    const TYPE_ID = 90;
    const HEIGHT = 0.6;

}
