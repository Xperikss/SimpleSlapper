<?php

declare(strict_types=1);

namespace SS\entities;

class SlapperWither extends SlapperEntity {

    const TYPE_ID = 52;
    const HEIGHT = 3.5;

}
