<?php

declare(strict_types=1);

namespace SS\entities;

class SlapperZombie extends SlapperEntity {

    const TYPE_ID = 32;
    const HEIGHT = 1.95;

}