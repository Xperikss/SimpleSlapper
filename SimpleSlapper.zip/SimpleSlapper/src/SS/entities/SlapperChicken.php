<?php

declare(strict_types=1);

namespace SS\entities;

class SlapperChicken extends SlapperEntity {

    const TYPE_ID = 10;
    const HEIGHT = 0.7;

}
