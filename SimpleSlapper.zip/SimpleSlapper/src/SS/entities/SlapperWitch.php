<?php

declare(strict_types=1);

namespace SS\entities;

class SlapperWitch extends SlapperEntity {

    const TYPE_ID = 45;
    const HEIGHT = 1.95;

}
